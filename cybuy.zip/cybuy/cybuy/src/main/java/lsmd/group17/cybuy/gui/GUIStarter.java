package lsmd.group17.cybuy.gui;

public class GUIStarter {

    public static void main(final String[] args) {
        CybuyGUI.main(args);
    }

}
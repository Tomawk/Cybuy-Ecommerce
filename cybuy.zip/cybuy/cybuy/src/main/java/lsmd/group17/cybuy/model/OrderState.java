package lsmd.group17.cybuy.model;

public enum OrderState {
    pending,
    sent,
    delivered,
    arrived,
    cancelled,
}

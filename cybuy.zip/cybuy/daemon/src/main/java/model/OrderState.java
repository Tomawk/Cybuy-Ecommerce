package model;

public enum OrderState {
    pending,
    sent,
    delivered,
    arrived,
    cancelled,
}
